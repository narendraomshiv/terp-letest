// export const API_BASE_URL = "https://siameats.com/api/"
export const API_BASE_URL = "http://192.168.1.10:5001/api/";
//server url 13.51.205.211