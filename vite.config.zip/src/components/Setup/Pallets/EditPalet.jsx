const EditPallet = () => {
	return <div>EditPallet</div>
}

export default EditPallet
