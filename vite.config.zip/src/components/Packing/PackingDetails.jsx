const PackingDetails = () => {
	return <div>PackingDetails</div>
}

export default PackingDetails
