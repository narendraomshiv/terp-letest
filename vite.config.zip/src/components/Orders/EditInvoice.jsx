const EditInvoice = () => {
	return <div>EditInvoice</div>
}

export default EditInvoice
