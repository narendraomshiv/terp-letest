const OperationDetails = () => {
	return <div>OperationDetails</div>
}

export default OperationDetails
