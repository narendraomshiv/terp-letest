const Invoice = () => {
	return <div>Invoice</div>
}

export default Invoice
